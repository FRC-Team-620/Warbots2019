/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package org.usfirst.frc620.Warbots2019.robot;

import org.usfirst.frc620.Warbots2019.drivetrain.DriveWithJoystick;
import org.usfirst.frc620.Warbots2019.automation.DepositCargo;
import org.usfirst.frc620.Warbots2019.automation.DepositHatch;
import org.usfirst.frc620.Warbots2019.drivetrain.TurnAngle;
import org.usfirst.frc620.Warbots2019.drivetrain.DriveStraight;
import org.usfirst.frc620.Warbots2019.elevator.MoveElevatorTo;
import org.usfirst.frc620.Warbots2019.elevator.ControlElevatorWithJoystick;

import edu.wpi.first.wpilibj.command.Subsystem;

/**
 * Add your docs here.
 */
public class CommandController extends Subsystem {
  // Put methods for controlling this subsystem
  // here. Call these from Commands.

  @Override
  public void initDefaultCommand() {
    // Set the default command for a subsystem here.
    setDefaultCommand(new DriveWithJoystick());
  }

  public static void startCommand(String string){
      if(string.equals("DepositCargo")){
          DepositCargo dc = new DepositCargo();
          dc.start();
      }
      if(string.equals("DepositHatch")){
        DepositHatch dh = new DepositHatch();
        dh.start();
      }
      if(string.equals("Turn90Right")){
        TurnAngle ta = new TurnAngle(90);
        ta.start();
      }
      if(string.equals("Turn90Left")){
        TurnAngle ta = new TurnAngle(-90);
        ta.start();
      }
      if(string.equals("Turn180")){
        TurnAngle ta = new TurnAngle(180);
        ta.start();
      }
      if(string.equals("DriveStraight")){
        DriveStraight ds = new DriveStraight(4.0);
        ds.start();
      }
  }
}
